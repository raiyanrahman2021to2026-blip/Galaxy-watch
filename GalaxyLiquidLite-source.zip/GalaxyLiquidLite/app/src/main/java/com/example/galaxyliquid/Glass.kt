package com.example.galaxyliquid

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

val NIGHT = Color.rgb(3, 9, 18)
val ICE = Color.rgb(130, 204, 255)
val MUTED = Color.rgb(156, 184, 206)

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/**
 * "Liquid glass" look bina real blur ke: translucent gradient + patli bright outline.
 * Ye sirf ek simple drawable hai, isliye GPU/RAM/battery pe lagbhag zero load.
 */
fun Context.glass(radiusDp: Float, strong: Boolean = false): GradientDrawable {
    val top = Color.argb(if (strong) 120 else 64, 130, 204, 255)
    val bottom = Color.argb(if (strong) 44 else 14, 130, 204, 255)
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
        cornerRadius = dp(radiusDp).toFloat()
        setStroke(dp(1f), Color.argb(if (strong) 190 else 110, 130, 204, 255))
    }
}

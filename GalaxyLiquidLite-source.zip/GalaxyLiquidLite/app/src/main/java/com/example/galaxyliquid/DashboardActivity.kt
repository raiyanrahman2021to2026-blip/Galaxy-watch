package com.example.galaxyliquid

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/**
 * Liquid Dashboard: time, date, battery, aur Apps button.
 * Koi polling/timer nahi. TextClock khud minute pe update hota hai (sirf screen on hone par),
 * battery sirf screen khulne par ek baar padhi jaati hai.
 */
class DashboardActivity : Activity() {

    private lateinit var battery: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(NIGHT))

        val tag = TextView(this).apply {
            text = "LIQUID DASHBOARD"
            setTextColor(ICE)
            textSize = 9f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.15f
        }
        val time = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            setTextColor(Color.WHITE)
            textSize = 46f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }
        val date = TextClock(this).apply {
            format12Hour = "EEE, d MMM"
            format24Hour = "EEE, d MMM"
            setTextColor(MUTED)
            textSize = 12f
        }
        battery = TextView(this).apply {
            setTextColor(ICE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = glass(18f)
            setPadding(dp(16f), dp(7f), dp(16f), dp(7f))
        }
        val open = TextView(this).apply {
            text = "OPEN APPS"
            setTextColor(Color.WHITE)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = glass(18f, strong = true)
            setPadding(dp(22f), dp(9f), dp(22f), dp(9f))
            isClickable = true
            setOnClickListener {
                startActivity(Intent(this@DashboardActivity, DrawerActivity::class.java))
            }
        }

        fun lp(topDp: Float) = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(topDp)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(tag, lp(0f))
            addView(time, lp(2f))
            addView(date, lp(0f))
            addView(battery, lp(12f))
            addView(open, lp(8f))
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        // Sticky broadcast: receiver register kiye bina ek baar value mil jaati hai.
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        battery.text = "Battery $pct%" + if (charging) " • charging" else ""
    }
}

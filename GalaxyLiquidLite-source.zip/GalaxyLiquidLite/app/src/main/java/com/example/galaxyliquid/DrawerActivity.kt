package com.example.galaxyliquid

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.TextView

/** Liquid App Drawer: plain GridView, view recycling, no icons/bitmaps = kam RAM. */
class DrawerActivity : Activity() {

    private class App(val label: String, val component: ComponentName)
    private class Holder(val badge: TextView, val name: TextView)

    private val apps = ArrayList<App>()
    private lateinit var appAdapter: BaseAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(NIGHT))

        val title = TextView(this).apply {
            text = "LIQUID APPS"
            setTextColor(ICE)
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.15f
            setPadding(0, dp(22f), 0, dp(4f))
        }

        appAdapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val cell = convertView ?: buildCell()
                val holder = cell.tag as Holder
                val app = apps[position]
                holder.badge.text = app.label.take(1).uppercase()
                holder.name.text = app.label
                return cell
            }
        }

        val grid = GridView(this).apply {
            numColumns = 3
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            horizontalSpacing = dp(4f)
            verticalSpacing = dp(8f)
            selector = ColorDrawable(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(dp(26f), dp(6f), dp(26f), dp(44f))
            adapter = appAdapter
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
            isFocusable = true
            isFocusableInTouchMode = true
            // Rotating bezel / crown se scroll
            setOnGenericMotionListener { _, e ->
                if (e.action == MotionEvent.ACTION_SCROLL &&
                    e.isFromSource(InputDevice.SOURCE_ROTARY_ENCODER)
                ) {
                    val d = -e.getAxisValue(MotionEvent.AXIS_SCROLL) *
                        ViewConfiguration.get(this@DrawerActivity).scaledVerticalScrollFactor
                    scrollListBy(d.toInt())
                    true
                } else false
            }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(grid, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        grid.requestFocus()

        Thread {
            val list = queryApps()
            runOnUiThread {
                if (!isFinishing && !isDestroyed) {
                    apps.clear()
                    apps.addAll(list)
                    appAdapter.notifyDataSetChanged()
                }
            }
        }.start()
    }

    private fun buildCell(): View {
        val badge = TextView(this).apply {
            gravity = Gravity.CENTER
            setTextColor(ICE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            background = glass(20f)
            layoutParams = LinearLayout.LayoutParams(dp(40f), dp(40f))
        }
        val name = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 9f
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(3f), 0, 0)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(badge)
            addView(name)
            tag = Holder(badge, name)
        }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<App> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map {
                App(
                    it.loadLabel(packageManager).toString(),
                    ComponentName(it.activityInfo.packageName, it.activityInfo.name)
                )
            }
            .distinctBy { it.component.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun launch(app: App) {
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(app.component)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            )
        } catch (_: ActivityNotFoundException) {
        } catch (_: SecurityException) {
        }
    }
}

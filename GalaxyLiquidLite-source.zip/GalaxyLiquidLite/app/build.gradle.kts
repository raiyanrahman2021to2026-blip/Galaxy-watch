plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.galaxyliquid"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.galaxyliquid"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-lite"
    }

    buildTypes {
        release {
            // R8 shrink = chhota APK. Debug key se sign hota hai taaki seedha install ho sake.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Jaanbujhkar: NO Compose, NO Material, NO AppCompat. Sirf plain Android Views = kam RAM.
dependencies {
    implementation("androidx.wear.tiles:tiles:1.4.1")
    implementation("androidx.wear.protolayout:protolayout:1.2.1")
    implementation("com.google.guava:guava:32.1.3-android")
}

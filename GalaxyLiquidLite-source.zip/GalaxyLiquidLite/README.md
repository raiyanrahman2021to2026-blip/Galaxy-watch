# Galaxy Liquid Lite (Watch 6)

Teen cheezein: Liquid App Drawer, Liquid Dashboard, Liquid Tiles (2 tiles).

## RAM / battery ke liye kya kiya
- Compose, Material, AppCompat sab hata diya. Sirf plain Android Views.
- Koi background service, wallpaper, network, ya timer nahi.
- Glass = translucent gradient + outline (real blur nahi, isliye halka).
- App icons load nahi hote (sirf pehla letter), to bitmap memory zero.
- Tiles static hain, kabhi refresh nahi hote.
- Ye system launcher replace nahi karta. App band = RAM free.

## Build (tablet se)
1. Is folder ko GitHub repo me upload karo.
2. Actions tab -> "Build APK" -> Run workflow.
3. Artifact galaxy-liquid-apk download karo, zip me se app-release.apk nikalo.
4. Bugjaeger se watch pe install karo.

## Use
- Watch app list me "Liquid Dashboard" aur "Liquid Apps" dikhenge.
- Tile list me "Liquid Dashboard" / "Liquid Apps" add karo.

Note: ye abhi compile ya real Watch 6 pe test nahi hua hai.
